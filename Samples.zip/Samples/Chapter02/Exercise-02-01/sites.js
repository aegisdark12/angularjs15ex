﻿var sites = [
  "Shaab El Erg",
  "Abu Gotta Ramada",
  "El Arouk",
  "Small Giftun",
  "Erg Somaya"
];
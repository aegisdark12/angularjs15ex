﻿var dives = [
  {
    site: 'Abu Gotta Ramada',
    location: 'Hurghada, Egypt',
    depth: 72,
    time: 54,
    divedOn: '2012-09-27T09:25:00.000Z'
  },
  {
    site: 'Ponte Mahoon',
    location: 'Maehbourg, Mauritius',
    depth: 54,
    time: 38,
    divedOn: '2009-01-18T07:48:00.000Z'
},
  {
    site: 'Molnar Cave',
    location: 'Budapest, Hungary',
    depth: 98,
    time: 62,
    divedOn: '2008-12-07T11:00:00.000Z'
  }];

﻿angular.module('maintenance', [])
  .controller('sitesCtrl', SitesCtrl)
  .controller('typesCtrl', TypesCtrl);

function SitesCtrl(currentSpot) {
}

function TypesCtrl() {
}
